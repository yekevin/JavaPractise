#!/bin/bash
URL="http://easyjob.d.zd.com"
STATUS_CODE="302"
#echo "URL: $URL"
#echo "STATUS_CODE: $STATUS_CODE"
RESULT=`curl -Is $URL | head -n 1 | grep $STATUS_CODE`
#echo "$RESULT"
if [ -n "$RESULT" ]; then
    echo "success"
    exit 0
else
    echo "fail"
    exit 1
fi
